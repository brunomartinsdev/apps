//Chrome Extension
// Set up context menu at install time.
chrome.runtime.onInstalled.addListener(function() {
  var context = "all";
  var title = "Open with Browser ChooserX";
  var id = chrome.contextMenus.create({"title": title, "contexts":[context],
                                         "id": "context" + context});  
});


chrome.contextMenus.onClicked.addListener(function(info, tab) {
  openWithBrowserChooserX(info.linkUrl);
   
});
chrome.browserAction.onClicked.addListener(function(tab) {
  openWithBrowserChooserX(tab.url);
});

function openWithBrowserChooserX(urlToOpen){
    var bcxUrl = "browserchooserx://"+urlToOpen;
    var bcxIFrame = document.createElement("iframe");
    bcxIFrame.setAttribute("sandbox", "");
    bcxIFrame.setAttribute("src", bcxUrl);
    document.body.appendChild(bcxIFrame);
}



