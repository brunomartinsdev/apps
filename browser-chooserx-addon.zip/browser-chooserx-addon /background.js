//Firefox Extension
function onCreated(n) {
}

browser.contextMenus.create({
  id: "open-with-bcx",
  title: "Open with Browser ChooserX",
  contexts: ["all"]
}, onCreated);

function openWithBrowserChooserX(urlToOpen){
	
    var bcxUrl = "browserchooserx://"+urlToOpen;
    chrome.tabs.update({
    	url:bcxUrl
    });
    
}
 
browser.contextMenus.onClicked.addListener(function(info, tab) {
  switch (info.menuItemId) {
    case "open-with-bcx":
      var urlToOpen = info.linkUrl;
      openWithBrowserChooserX(urlToOpen)
      break;
    
  }
});
browser.browserAction.onClicked.addListener(function(tab) {
  openWithBrowserChooserX(tab.url);
});
